const knex = require("knex");
const knexFile = require("../database/knexfile");
const db = knex(knexFile);

module.exports = {
  db,

  findAllAssets() {
    // Fetch all assets and include employee name and department from the employee_details table
    return db("asset_inventory")
      .select(
        "asset_inventory.*",
        "employee_details.empname as employee_name",
        "employee_details.department"
      )
      .leftJoin(
        "employee_details",
        "asset_inventory.empid",
        "employee_details.empid"
      );
  },

  updateAsset: async (serialNo, updatedFields) => {
    try {
      const result = await db("asset_inventory")
        .where("serial_no", serialNo)
        .update(updatedFields);

      return result;
    } catch (error) {
      console.error("Error updating asset:", error);
      throw error;
    }
  },
  deleteAssetBySerialNumber(serialNumber) {
    return db("asset_inventory").where("serial_no", serialNumber).del();
  },
  createAsset(assetData) {
    return db("asset_inventory").insert(assetData);
  },
  getDistinctItems() {
    return db("asset_inventory")
      .select("asset_type", db.raw("count(1) as total"))
      .groupBy("asset_type");
  },

  // Additional methods for asset CRUD operations can be added here...
};
