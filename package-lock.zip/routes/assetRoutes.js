const express = require("express");
const router = express.Router();
const assetModel = require("../model/assetModel"); // Adjust the path as needed
const knex = require("knex");
const knexFile = require("../database/knexfile");
// const bcrypt = require("bcrypt");
const db = knex(knexFile);

// Route to get all assets
router.get("/all", async (req, res) => {
  try {
    const assets = await assetModel.findAllAssets();
    res.json(assets);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

// router to get distinct assets and its count

router.get("/asset_type_cnt", async (req, res) => {
  try {
    const type = await assetModel.getDistinctItems();
    res.json(type);
    res.status(200);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Unable to get all records" });
  }
});

router.put("/assetUpdate/:serialNo", async (req, res) => {
  try {
    const serialNo = req.params.serialNo;
    const updatedData = req.body;

    // Check if serial number is provided
    if (!serialNo) {
      return res.status(400).json({ error: "Serial number is required" });
    }

    // Check if the asset exists
    const existingAsset = await assetModel.findAllAssets(serialNo);

    if (!existingAsset || existingAsset.length === 0) {
      return res.status(404).json({ error: "Asset not found" });
    }

    // Update the asset
    await assetModel.updateAsset(serialNo, updatedData);

    return res.status(200).json({ success: true });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: "Internal Server Error" });
  }
});

router.delete("/assetDelete/:serialNumber", async (req, res) => {
  try {
    const { serialNumber } = req.params;

    // Check if serial number is provided
    if (!serialNumber) {
      return res.status(400).json({ error: "Serial number is required" });
    }

    // Delete the asset entry
    await assetModel.deleteAssetBySerialNumber(serialNumber);

    return res
      .status(200)
      .json({ success: true, message: "Asset deleted successfully" });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: "Internal Server Error" });
  }
});

router.post("/assetAdd", async (req, res) => {
  try {
    const {
      empid,
      serial_no,
      asset_type,
      make_model,
      quantity,
      location,
      condition,
      processor,
      generation,
      disk_type,
      disk_size,
      ram,
      po_number,
      warrenty_date,
      status,
      expires_in,
    } = req.body;

    // Check if all required details are provided
    if (
      !(
        empid &&
        serial_no &&
        asset_type &&
        make_model &&
        quantity &&
        location &&
        condition
      )
    ) {
      return res.status(400).json({ error: "All details are required" });
    }

    // Check if the employee exists
    const employee = await db("employee_details")
      .where("empid", empid)
      .select("empid")
      .first();

    if (!employee) {
      return res.status(404).json({ error: "Employee not found" });
    }

    // Check if the serial number is already available
    const existingAsset = await db("asset_inventory")
      .where("serial_no", serial_no)
      .select("serial_no")
      .first();

    if (existingAsset) {
      return res
        .status(400)
        .json({ error: "Serial number is already available" });
    }

    // Proceed to add the asset
    const assetData = {
      empid,
      serial_no,
      asset_type,
      make_model,
      quantity,
      location,
      condition,
      processor,
      generation,
      disk_type,
      disk_size,
      ram,
      po_number,
      warrenty_date,
      status,
      expires_in,
    };

    await assetModel.createAsset(assetData);

    return res
      .status(201)
      .json({ success: true, message: "Asset added successfully" });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: "Internal Server Error" });
  }
});

module.exports = router;
