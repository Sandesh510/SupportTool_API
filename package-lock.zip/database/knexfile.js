module.exports = {
  client: "pg",
  connection: {
    host: "localhost",
    user: "postgres", // Replace with your database username
    password: "Admin$123", // Replace with your database password
    database: "KnexPractice", // Replace with your database name
  },
  migrations: {
    tableName: "knex_migrations",
    directory: "./database/migrations",
  },
  plugins: ["knex-schema-inspector"],
  useNullAsDefault: true,
};
